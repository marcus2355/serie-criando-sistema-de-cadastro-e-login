----
## *Goodbye :)* {#goodbye}

Olá, como vai você? Desde já, quero te parabenizar por concluir a leitura dessa extensa documentação. Conheço muito bem a dificuldade de se estudar frameworks com documentações confusas e muito diretas e, por isso, busquei trazer mais do que meramente um manual, mas, sim, algo como uma apostila ou um e-book. Lembre-se que esta documentação reúne diversos conceitos e boas práticas que podem aprimorar, ainda mais, os seus códigos.

O HXPHP não foi desenvolvido para ser o <b>framework perfeito</b>, nem o <b>framework do código lindo</b> e sim, na verdade, ser o <b>framework de iniciação</b> dos programadores PHP. Trata-se de uma ferramenta simples que tem o objetivo nobre de apresentar o universo dos frameworks com um primeiro contato fácil e produtivo. E, para isso, em poucas horas o programador já é capaz de criar diversas soluções; fator este mais do que estimulante.

Lembre-se também que antes de estudar um framework é mais do que recomendado, imprescindível, o domínio da linguagem PHP em si. Afinal, independente do framework, você deve ser um programador PHP.

Te desejo muito sucesso e espero que você nunca pare de estudar, pois a tecnologia não para e nós, por mais difícil que seja, devemos acompanhar esta evolução.

Um forte abraço do seu amigo [Bruno Campos Santos](https://www.facebook.com/brunocsantos2012 "Bruno Campos Santos").