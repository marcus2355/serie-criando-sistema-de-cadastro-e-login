# HXPHP Framework

O HXPHP é um mini-framework PHP.

### Qual é a diferença do HXPHP e os demais frameworks PHP?
--------------------------------------------------------------------

O HXPHP não foi desenvolvido para ser o **framework perfeito**, nem o **framework do código lindo** e sim, na verdade, ser o **framework de iniciação** dos programadores PHP. Trata-se de uma ferramenta simples que tem o objetivo nobre de apresentar o universo dos frameworks com um primeiro contato fácil e produtivo. E, para isso, em poucas horas o programador já é capaz de criar diversas soluções; fator este mais do que estimulante.

Lembre-se também que antes de estudar um framework é mais do que recomendado, imprescindível, o domínio da linguagem PHP em si. Afinal, independente do framework, você deve ser um programador PHP.

--------------------------------------------------------------------

> Te desejo muito sucesso e espero que você nunca pare de estudar, pois a tecnologia não para e nós, por mais difícil que seja, devemos acompanhar esta evolução.

###### Um forte abraço do seu amigo [Bruno Campos Santos](https://www.facebook.com/brunocsantos2012 "Bruno Campos Santos").

####Link para documentação:
---------------------------------------------------------------------
[https://github.com/brunosantoshx/hxphp-docs](https://github.com/brunosantoshx/hxphp-docs).