<?php 

class Example extends \HXPHP\System\Model
{
	
}